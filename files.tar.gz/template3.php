<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<div id="chat-wrap">

  <h1>Chat Window</h1>

  <div id="user-name"></div>

  <div id="chat-box"><div id="chat-row"></div></div>

  <form id="send-message-area">

    <p>Your message: </p>

    <textarea id="posttext" maxlength="120"></textarea>

  </form>

</div>

</body>
</html>





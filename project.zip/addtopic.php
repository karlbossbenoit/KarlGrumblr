<?php
require 'db.php';
session_start();

$username= $_SESSION['login'];
//echo $username;
$query =$db->query("SELECT user_id FROM user_information WHERE user_name='$username'");
$result = $query->fetch_assoc();
$id= $result['user_id'];

//<!--  The counters are there to split points for distribution within the topics (specifically the user_points collumns with the family life and working tables) -->
$count =0;
if(isset($_POST['family'])){
	$count++;
}
if(isset($_POST['work'])){
	$count++;
}
if(isset($_POST['school'])){
	$count++;
}

$points = 20/$count;
//echo$count;
//echo$points;
/////////

/////////

//<!-- THIS DISTRBUTES THE POINTS INTO THE COLUMNS OF THE TABLES  -->
if(isset($_POST['family'])){

	$set_fam_points=  $db->query("UPDATE family_life SET user_points='$points' WHERE user_id='$id'");
	
	//TEST TO SEE IF THE STATEMENT WAS PERFORMED\\
	/*$famresult= $db->query("SELECT * FROM family_life WHERE user_id='$id'");
	$testfam= $famresult->fetch_assoc();
	echo $testfam['user_points'];*/
	///////////////////////////////////////////
	
}
if(isset($_POST['work'])){

	$set_working_points= $db->query("UPDATE working SET user_points='$points' WHERE user_id='$id'");
	
	//TEST TO SEE IF THE STATEMENT WAS PERFORMED\\
	/*$workresult= $db->query("SELECT * FROM working WHERE user_id='$id'");
	$testwork= $workresult->fetch_assoc();
	echo $testwork['user_points'];*/
	///////////////////////////////////////////
}
if(isset($_POST['school'])){

	$set_school_points= $db->query("UPDATE school SET user_points='$points' WHERE user_id='$id'");
	
	//TEST TO SEE IF THE STATEMENT WAS PERFORMED\\
	/*$workresult= $db->query("SELECT * FROM working WHERE user_id='$id'");
	$testwork= $workresult->fetch_assoc();
	echo $testwork['user_points'];*/
	///////////////////////////////////////////
}




//Seleect all user_names if () john=>family.user_points/ karl=>famil.user_points < $sumnum
//						        /\						   /\
//					      query john's user_points	  query karl's user_points
//we then give them the names of all those people and they can choose who they want to  connect with
//if they don't want to choose them then we can choose for them based off the percent difference that gests
//displayed also from the query of similar users 



?>



<!--
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>TOPIC(s) HAVE BEEN ADDED </h1>
</body>
</html>-->
